import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { PatientService } from "../service/patient.service";
import { Patient } from "../model/patient.model";

@Component({
  selector: 'app-list-patient',
  templateUrl: './list-patient.component.html',
  styleUrls: ['./list-patient.component.css']
})
export class ListPatientComponent implements OnInit {

  patients: any;

  constructor(private router: Router, private patientService: PatientService) { }

  ngOnInit() {

    var patients = JSON.parse(localStorage.getItem("patients"));

    if (patients && patients.length > 0) {
      this.patients = patients;
    } else {
      this.patientService.getPatients()
        .subscribe(data => {
          this.patients = data;
          localStorage.setItem("patients", JSON.stringify(this.patients));
        });
    }
  }  

  editUser(patientId): void {    
    this.router.navigate(['add-patient'], { queryParams: { patientId: patientId } });
  };

  addUser(): void {
    this.router.navigate(['add-patient']);
  };
}
