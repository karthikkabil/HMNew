export class Patient {

  PatientID: string;
  Name: string;
  Contact: number;  
}
