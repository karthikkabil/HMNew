import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { PatientService } from "../service/patient.service";
import { first } from "rxjs/operators";
import { Router, ActivatedRoute } from "@angular/router";

@Component({
  selector: 'app-add-patient',
  templateUrl: './add-patient.component.html',
  styleUrls: ['./add-patient.component.css']
})
export class AddPatientComponent implements OnInit {

  constructor(private route: ActivatedRoute, private formBuilder: FormBuilder,
    private router: Router, private userService: PatientService) { }

  addForm: FormGroup;
  patientId: any;
  patients: any;
  btnName: string;
  disablePatientId: boolean;
  emailPattern = "^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$";
  phoneNumberPattern = "^(\+\d{1,3}[- ]?)?\d{10}$";

  ngOnInit() {

    this.patients = JSON.parse(localStorage.getItem("patients"));

    this.route.queryParams
      .subscribe(params => {
        console.log(params);
        this.patientId = params.patientId;
        if (this.patientId) {
          this.btnName = "Update";
          this.disablePatientId = true;
        } else {
          this.btnName = "Submit";
          this.disablePatientId = false;
        }
        this.initializeForm();
        this.assignFormValues();
      }
      );

  }

  initializeForm() {

    this.addForm = this.formBuilder.group({
      patientId: ['', Validators.required],
      email: ['', [Validators.required, Validators.pattern("[a-zA-Z0-9._%+-]{1,}@[a-zA-Z0-9.-]{2,}[.]{1}[a-zA-Z]{2,}")]],
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      age: ['', Validators.required],
      phoneNumber: ['', [Validators.required, Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]]
    });
  }

  assignFormValues() {
    const patient = this.patients.filter(x => x.patientID === this.patientId)[0];

    if (patient) {
      this.addForm.controls.patientId.setValue(patient.patientID);
      this.addForm.controls.email.setValue(patient.email);
      this.addForm.controls.firstName.setValue(patient.firstName);
      this.addForm.controls.lastName.setValue(patient.lastName);
      this.addForm.controls.age.setValue(patient.age);
      this.addForm.controls.phoneNumber.setValue(patient.phoneNumber);
    }
  }

  onSubmit() {

    this.validateFormFields();

    if (this.addForm.invalid) {
      return;
    }

    const patient = this.getFormValues();

    if (this.btnName == "Update") {
      var index = this.patients.findIndex(x => x.patientID === patient.patientID);
      if (index !== -1) {
        this.patients[index] = patient;
      }
    }
    else {
      this.patients.push(patient);
    }
    localStorage.setItem("patients", JSON.stringify(this.patients));
    this.router.navigateByUrl('\list-patient');
  }

  validateFormFields() {
    if (this.addForm.get('patientId').value === '') {
      this.addForm.get('patientId').setErrors({ 'patientIdReq': true });
    }
    if (this.addForm.get('email').value === '') {
      this.addForm.get('email').setErrors({ 'emailReq': true });
    }
    if (this.addForm.get('firstName').value === '') {
      this.addForm.get('firstName').setErrors({ 'firstNameReq': true });
    }
    if (this.addForm.get('lastName').value === '') {
      this.addForm.get('lastName').setErrors({ 'lastNameReq': true });
    }
    if (this.addForm.get('age').value === '') {
      this.addForm.get('age').setErrors({ 'ageReq': true });
    }
    if (this.addForm.get('phoneNumber').value === '') {
      this.addForm.get('phoneNumber').setErrors({ 'phoneNumberReq': true });
    }
  }


  private getFormValues() {

    const patientId = this.addForm.controls.patientId.value;
    const email = this.addForm.controls.email.value;
    const firstName = this.addForm.controls.firstName.value;
    const lastName = this.addForm.controls.lastName.value;
    const age = this.addForm.controls.age.value;
    const phoneNumber = this.addForm.controls.phoneNumber.value;
    const patient = {
      patientID: patientId,
      email: email,
      firstName: firstName,
      lastName: lastName,
      phoneNumber: phoneNumber,
      age: age
    };
    return patient;
  }
}
