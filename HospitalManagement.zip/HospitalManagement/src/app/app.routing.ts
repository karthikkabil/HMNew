import { RouterModule, Routes } from '@angular/router';
import {LoginComponent} from "./login/login.component";
import { AddPatientComponent } from "./add-patient/add-patient.component";
import {ListPatientComponent} from "./list-patient/list-patient.component";


const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'add-patient', component: AddPatientComponent },
  { path: 'list-patient', component: ListPatientComponent },  
  {path : '', component : LoginComponent}
];

export const routing = RouterModule.forRoot(routes);
