import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Patient } from "../model/patient.model";

@Injectable()
export class PatientService {
  constructor(private http: HttpClient) { }
  

  getPatients() {
    return this.http.get("./assets/patient-list.json");
  }
  
}
